package com.minutes.course.SpringbootProject;

import java.sql.Timestamp;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringBootController {

	@GetMapping(path = "/currentTimestamp")
	public String getCurrentTimestamp() {
		return new Timestamp(System.currentTimeMillis()).toString();
	}
}
