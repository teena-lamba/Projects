module WarehouseManagementSystem {
}