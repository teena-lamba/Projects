package WarehouseManagement.Interface;

import java.util.List;

import WarehouseManagement.Model.Stock;

public interface StockInterface {

	public  List<Stock> getStockInfoBySortOrder(List<Stock> stockList, String order);
	
}
