package WarehouseManagement;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import WarehouseManagement.Interface.StockInterface;
import WarehouseManagement.Model.Stock;
import WarehouseManagement.Service.StockService;

public class StockMain {
	public static void main(String arr[]) throws ParseException {
		StockInterface stockInterface = new StockService();
		
		List<Stock> stocks = new ArrayList<>();
		SimpleDateFormat s = new SimpleDateFormat("yyyy/MM/dd");
		Stock stock1 = new Stock("4070071967071","B1",s.parse("2020/03/25"),s.parse("2020/03/25"),1234.56);
		stocks.add(stock1);
		Stock stock2 = new Stock("4070071967072","B2",s.parse("2020/03/26"),s.parse("2020/03/25"),1234.56);
		stocks.add(stock2);
		Stock stock3 = new Stock("4070071967073","B3",s.parse("2020/02/25"),s.parse("2020/03/25"),1234.56);
		stocks.add(stock3);
		Stock stock4 = new Stock("4070071967074","B4",s.parse("2020/03/29"),s.parse("2020/03/25"),1234.56);
		stocks.add(stock4);
		Stock stock5 = new Stock("4070071967075","B5",s.parse("2020/02/2"),s.parse("2020/03/25"),1234.56);
		stocks.add(stock5);
		
		List<Stock> stocks1 = stockInterface.getStockInfoBySortOrder(stocks, "Desc");
		
		for(Stock s1:stocks1) {
			System.out.println(s1.getBatchNumber()+" "+s1.getProductCode()+" "+s1.getQuantity()+" "+s1.getManufacturingDate());
		}
		List<Stock> stocks2 = stockInterface.getStockInfoBySortOrder(stocks, "Asc");
		System.out.println("====================");
		for(Stock s1:stocks2) {
			System.out.println(s1.getBatchNumber()+" "+s1.getProductCode()+" "+s1.getQuantity()+" "+s1.getManufacturingDate());
		}				
	}
}
