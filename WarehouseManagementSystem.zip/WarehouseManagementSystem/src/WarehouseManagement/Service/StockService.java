package WarehouseManagement.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import WarehouseManagement.Interface.StockInterface;
import WarehouseManagement.Model.Stock;

public class StockService implements StockInterface{

	@Override
	public List<Stock> getStockInfoBySortOrder(List<Stock> stockList, String order) {
		// TODO Auto-generated method stub
		Comparator<Stock> comparator = (prod1, prod2) -> Long.valueOf(
                prod1.getManufacturingDate().getTime())
                .compareTo(prod2.getManufacturingDate().getTime()
                        );
		if(order.equalsIgnoreCase("Desc")) {
		 Collections.sort(stockList, comparator.reversed());
		}else {
			Collections.sort(stockList, comparator);
		}
		return stockList;
	}


}
